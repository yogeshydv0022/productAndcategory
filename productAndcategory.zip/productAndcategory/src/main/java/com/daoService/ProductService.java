package com.daoService;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.dtoService.ProductDTO;
import com.entity.Category;
import com.entity.Product;
import com.exception.CustomException;
import com.repository.CategoryRepository;
import com.repository.ProductRepository;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
   
    @Autowired
    private ModelMapper modelMapper; 

    
    private ProductDTO convertToDTO(Product product) {
        return modelMapper.map(product, ProductDTO.class);
    }

    private Product convertToEntity(ProductDTO productDTO) {
        return modelMapper.map(productDTO, Product.class);
    }
    
    
    //create Product
    public ProductDTO createProduct(ProductDTO productDTO) {
        Product product = convertToEntity(productDTO);
        Product savedProduct = productRepository.save(product);
        return convertToDTO(savedProduct);
    }
    
    //getAllProduct
    public List<ProductDTO> getAllProducts() {
        List<Product> products = productRepository.findAll();
        return products.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    //getByIdProduct
    public ProductDTO getProductById(Long id) {
        Product product = productRepository.findById(id)
        		.orElseThrow(() -> new CustomException("product  not found enter valid id !!"));
        return convertToDTO(product);
    }


    //update Product ById
    public ProductDTO updateProduct(Long id, ProductDTO productDTO) {
        if (!productRepository.existsById(id)) {
            throw new CustomException("product  not found enter valid id ");
        }
        productDTO.setId(id);
        Product product = convertToEntity(productDTO);
        Product updatedProduct = productRepository.save(product);
        return convertToDTO(updatedProduct);
    }

    //delete Product
    public String deleteProduct(Long id) {
        if (!productRepository.existsById(id)) {
            throw new CustomException("product  not found enter valid id");
        }
        productRepository.deleteById(id);
		return "product deleted successfully";
    }
    
    // findProductByCategoryId
    public Category findProductByCategory(long catId){ 	
        Category catgeory=categoryRepository.findById(catId).orElseThrow();
        return catgeory;
    	
    }
    
    // Category findProductByName
    public Category findbyName(String name) {
    	Category catgeory=categoryRepository.findByName(name);
    	return catgeory;
    }
     
 	
 	//ProductByShorting
 	public List<Product>productWithShorting(String field){
		return productRepository.findAll(Sort.by(Sort.Direction.ASC,field));
		
 		
 	}
 	
 	//Product By Pagination
 	public Page<Product>pagination(int offset,int pageSize){
		return productRepository.findAll(PageRequest.of(offset,pageSize));	
 	}
 	
 	//Pagination And Shorting
 	public Page<Product>paginationAndShorting(int offset,int pageSize,String field){
		return productRepository.findAll(PageRequest.of(offset,pageSize).withSort(Sort.by(field)));
 	}
 	
 	//priceRange
 	public List<Product>priceRange(double min,double max){
		return productRepository.priceRange(min,max);
 		
 	}
 	
}