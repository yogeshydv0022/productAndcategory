package com.daoService;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dtoService.CategoryDTO;
import com.entity.Category;
import com.exception.CustomException;
import com.repository.CategoryRepository;

@Service
public class CategoryService {
	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private ModelMapper modelMapper;

	private CategoryDTO convertToDTO(Category category) {
		return modelMapper.map(category, CategoryDTO.class);
	}

	private Category convertToEntity(CategoryDTO categoryDTO) {
		return modelMapper.map(categoryDTO, Category.class);
	}

	// createCategory
	public CategoryDTO createCategory(CategoryDTO categoryDTO) {
		Category category = convertToEntity(categoryDTO);
		Category savedCategory = categoryRepository.save(category);
		return convertToDTO(savedCategory);
	}

	// getById
	public CategoryDTO getCategoryById(Long id) {
		Category category = categoryRepository.findById(id)
				.orElseThrow(() -> new CustomException("category  not found enter valid id !!"));
		return convertToDTO(category);
	}

	// getAllCategory
	public List<CategoryDTO> getAllCategories() {
		List<Category> categories = categoryRepository.findAll();
		return categories.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	// updateCategory
	public CategoryDTO updateCategory(Long id, CategoryDTO categoryDTO) {
		if (!categoryRepository.existsById(id)) {
			throw new CustomException("category  not found enter valid id !!");
		}
		categoryDTO.setId(id);
		Category category = convertToEntity(categoryDTO);
		Category updatedCategory = categoryRepository.save(category);
		return convertToDTO(updatedCategory);
	}

	// deleteCategory
	public void deleteCategory(Long id) {
		if (!categoryRepository.existsById(id)) {
			throw new CustomException("category  not found enter valid id !!");
		}
		categoryRepository.deleteById(id);
	}
	
	// ad

}