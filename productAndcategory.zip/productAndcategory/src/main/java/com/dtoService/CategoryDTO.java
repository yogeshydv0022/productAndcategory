package com.dtoService;

import lombok.Data;

@Data
public class CategoryDTO {
	
	private Long id;
	private String name;

}