package com.dtoService;

import java.util.Date;

import lombok.Data;

@Data
public class ProductDTO {
	
	private long id;
	private String pname;
    private String model;
    private String brand;
    private double price;
    private int quantity;
    
    private Date createAt=new Date();
    
    private Long categoryId;

    // Getters and Setters
}