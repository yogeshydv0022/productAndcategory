package com.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
//@Table(name="product_tbl")
public class Product {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String pname;
	    private String model;
	    private String brand;
	    private double price;
	    private int quantity;
	    private Date createAt;
	    
	    @ManyToOne(fetch = FetchType.LAZY)
	    @JsonBackReference
	    @JoinColumn(name = "category_id", nullable = false)
	    private Category category;

	

}
