package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

	// Find By Price Range Shorted By ASC Order
	
	//@Query("SELECT p FROM Product p WHERE p.price BETWEEN :minPrice AND :maxPrice ORDER BY p.price ASC")
	//public List<Product> findByPriceRangeASC(@Param("minPrice")double minPrice, @Param("maxPrice")double maxPrice);
	
	@Query("from Product where price between :min and :max")
	public List<Product> priceRange (@Param("min")double min, @Param("max")double max);

	
//	// Get all Products By Page With Default
//	@Query(value = "SELECT p FROM Product p")
//	Page<Product> getPersons(final Pageable pageable);

}
