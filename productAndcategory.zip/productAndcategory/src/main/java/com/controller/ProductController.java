package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.daoService.ProductService;
import com.dtoService.ProductDTO;
import com.entity.Category;
import com.entity.Product;

@RestController
@RequestMapping("/api/products")
public class ProductController {
	@Autowired
	private ProductService productService;

	// createProduct
	@PostMapping
	public ResponseEntity<?> createProduct(@RequestBody ProductDTO productDTO) {
		ResponseEntity<?> resp = null;
		try {
			ProductDTO products = productService.createProduct(productDTO);
			resp = new ResponseEntity<ProductDTO>(products, HttpStatus.CREATED);
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>("unable to create  products ", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// getProductById
	@GetMapping("/{id}")
	public ResponseEntity<?> getOneProduct(@PathVariable("id") long id) {
		ResponseEntity<?> resp = null;
		try {
			ProductDTO products = productService.getProductById(id);
			resp = new ResponseEntity<ProductDTO>(products, HttpStatus.FOUND);
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>("Product  not found enter valid id !!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// getAllProduct
	@GetMapping()
	public ResponseEntity<?> getAllProducts() {
		ResponseEntity<?> resp = null;
		try {
			List<ProductDTO> products = productService.getAllProducts();
			resp = new ResponseEntity<List<ProductDTO>>(products, HttpStatus.FOUND);
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>("unable to find all products", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// updateById
	@PutMapping("/{id}")
	public ResponseEntity<?> updateProduct(@PathVariable("id") Long id, @RequestBody ProductDTO productDTO) {
		ResponseEntity<?> resp = null;
		try {
			ProductDTO products = productService.updateProduct(id, productDTO);
			resp = new ResponseEntity<ProductDTO>(products, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>("product  not found enter valid id !!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// deleteProduct
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable("id") Long id) {
		ResponseEntity<?> resp = null;
		try {
			productService.deleteProduct(id);
			resp = new ResponseEntity<String>(id + " product deleted successfully", HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>("product not found enter valid id !! ", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// find product By category Id
	@GetMapping("/categoryId/{catId}")
	public ResponseEntity<?> getProductByCategory(@PathVariable("catId") Long catId) {
		ResponseEntity<?> resp = null;
		try {
			Category products = productService.findProductByCategory(catId);
			resp = new ResponseEntity<Category>(products, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>("product not found enter valid id !! ", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// find product By category Name
	@GetMapping("/categoryName/")
	public ResponseEntity<?> getProductByCategoryName(@RequestParam("name") String name) {
		ResponseEntity<?> resp = null;
		try {
			Category products = productService.findbyName(name);
			resp = new ResponseEntity<Category>(products, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			resp = new ResponseEntity<String>("product not found enter valid name !! ",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// priceRange
	@GetMapping("/priceRange/{min}/{max}")
	public ResponseEntity<?> priceRange(@PathVariable("min") double min, @PathVariable("max") double max) {
		ResponseEntity<?> resp = null;
		try {
			List<Product> products = productService.priceRange(min, max);
			resp = new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("product not found enter valid price !!",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// Pagination
	@GetMapping("/pagination/{offset}/{pagesize}")
	public ResponseEntity<?> Pagination(@PathVariable("offset") int offset, @PathVariable("pagesize") int pagesize) {
		ResponseEntity<?> resp = null;
		try {
			Page<Product> products = productService.pagination(offset, pagesize);
			// int product=products.getSize(); all size
			resp = new ResponseEntity<Page<Product>>(products, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("product not found enter valid price !!",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// paginationAndShorting
	@GetMapping("/pagination/{offset}/{pagesize}/{field}")
	public ResponseEntity<?> paginationAndShorting(@PathVariable("offset") int offset,
			@PathVariable("pagesize") int pagesize, @PathVariable("field") String field) {
		ResponseEntity<?> resp = null;
		try {
			Page<Product> products = productService.paginationAndShorting(offset,pagesize,field);
			// int product=products.getSize(); all size
			resp = new ResponseEntity<Page<Product>>(products, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("product not found enter valid field !!",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

}
