package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.daoService.CategoryService;
import com.dtoService.CategoryDTO;

@RestController
@RequestMapping("/api/categorys")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	// addCategory
	@PostMapping
	public ResponseEntity<?> addCategory(@RequestBody CategoryDTO categoryDTO) {
		ResponseEntity<?> resp = null;
		try {
			CategoryDTO products = categoryService.createCategory(categoryDTO);
			resp = new ResponseEntity<CategoryDTO>(products, HttpStatus.CREATED);
		} catch (Exception e) {
			resp = new ResponseEntity<String>("unable to add categories !! ",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}
	
	// getCategoryById
		@GetMapping("/{id}")
		public ResponseEntity<?> getOneCategory(@PathVariable("id") long id) {
			ResponseEntity<?> resp = null;
			try {
				CategoryDTO categorys = categoryService.getCategoryById(id);
				resp = new ResponseEntity<CategoryDTO>(categorys, HttpStatus.FOUND);
			} catch (Exception e) {
				e.printStackTrace();
				resp = new ResponseEntity<String>("category not found enter valid id !! ",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return resp;
		}

	// getCategorys
	@GetMapping
	public ResponseEntity<?> getAllCategories() {
		ResponseEntity<?> resp = null;
		try {
			List<CategoryDTO> products = categoryService.getAllCategories();
			resp = new ResponseEntity<List<CategoryDTO>>(products, HttpStatus.FOUND);
		} catch (Exception e) {
			resp = new ResponseEntity<String>("unable to find all categories !! ",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	

	// updateById
	@PutMapping("/{id}")	
	public ResponseEntity<?> updateCategory(@PathVariable("id") Long id, @RequestBody CategoryDTO categoryDTO) {
		ResponseEntity<?> resp = null;
		try {
			CategoryDTO category = categoryService.updateCategory(id, categoryDTO);
			resp = new ResponseEntity<CategoryDTO>(category, HttpStatus.OK);
		} catch (Exception e) {
			resp = new ResponseEntity<String>("unable to find  categories by id !! ",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	// deleteById
	@DeleteMapping("/{id}")	
	public ResponseEntity<?> deleteCategory(@PathVariable("id") Long id) {
		ResponseEntity<?> resp = null;
		try {
			categoryService.deleteCategory(id);
			resp = new ResponseEntity<String>(id+" :category deleted successfully", HttpStatus.OK);
		} catch (Exception e) {
			resp = new ResponseEntity<String>("unable to find  categories by id !! ",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

}